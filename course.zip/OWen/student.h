/**
 * @file student.h
 * @author Tinu Joseph
 * @brief houses the typedef for the Student object
 * @version 0.1
 * @date 2022-04-12
 */


/**
 * Creating a new type called Student with fields first_name, last_name, id, grades, num_grades
 */
typedef struct _student 
{ 
  char first_name[50]; /**< Students first name*/
  char last_name[50]; /**< Students lsdt name*/
  char id[11]; /**< Students id number*/
  double *grades;  /**< array of students grade*/
  int num_grades;  /**< number of grades of the student*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
