/**
 * @file student.c
 * @author Tinu Joseph
 * @brief Functions and implementations for the student struct
 * @version 0.1
 * @date 2022-04-12
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to a student's grade array
 * 
 * @param student a pointer to a Student struct
 * @param grade The grade to add to the student's list of grades.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //if the number of grades a student has is it allocates memory for one double in an array
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));

  //if the number of grades of a student is greater than 1, it reallocates memory to the number of grades the student has in the size of a double
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Takes a student and returns the students average grade
 * 
 * @param student a pointer to a Student struct
 * 
 * @return A pointer to a Student struct.
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  //iterates throught the grades of the student and add all the grades together while keeping track of how many grades there are
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}


/**
 * @brief It prints the student's name, id, grades, and average
 * 
 * @param student a pointer to a Student struct
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  //iterate through all the grades of the student to print them out
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief generates a student using the grades paramater for the numebr of grades the student needs
 * 
 * @param grades the number of grades to generate for the student
 * 
 * @return A pointer to a Student struct.
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}
