/**
 * @file course.c
 * @author Tinu Joseph
 * @brief Functions and implementations for the course Struct
 * @version 0.1
 * @date 2022-04-12
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Enrolls one additional student to the course. It does this using the pointer given to the function for the student and a pointer to the course struct
 * 
 * @param course A pointer to a Course struct.
 * @param student a pointer to a Student struct
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //if the number of students in the course is 1, then we allocate memory at the size of one student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //if the numebr of students in the course is more than one then we reallocate more memory to the array based on the numeber of students
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief It prints the name, code, and total students of a course, and then prints all the students in the course
 * 
 * @param course A pointer to a Course struct.
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //uses a for loop to iterate throught the array of students to print each individual student
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief It loops through the students in the course, and returns the student with the highest average
 * 
 * @param course a pointer to a Course struct
 * 
 * @return A pointer to a student.
 */
Student* top_student(Course* course)
{
  //return NULL if there are no students
  if (course->total_students == 0) return NULL;
 
  //Set the max average to the average of the first student and iterate the the array and change the varaible when a bigger average is found
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief It constructs an array of students and returns a pointer to that array of students who passed the course
 * 
 * @param course a pointer to a Course struct
 * @param total_passing This is a pointer to an integer. This is because we want to return the total number of students that passed the course.
 * 
 * @return A pointer to an array of students.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;

  //contructs an array of the number of students who passed using a for loop and interting through each student to see if their average is above 50
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  //adds the students name to the premade array on the condition that their average is above 50
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
