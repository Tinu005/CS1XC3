/**
 * @file main.c
 * @author Tinu Joseph
 * @brief The main file that uses the course library and functions from course.c and student.c
 * @version 0.1
 * @date 2022-04-12
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The main function that uses the course library and functions from course.c and student.c
 * 
 */
int main()
{
  //Setting up the random function for the generate_random_student
  srand((unsigned) time(NULL));

  //generates Course object
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //adds a random student with 8 grades to the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //prints out the student with the highest average in the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //prints out all the students who are passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}
