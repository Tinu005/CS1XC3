/**
 * @file course.h
 * @author Tinu Joseph
 * @brief houses the typedef for the Course object
 * @version 0.1
 * @date 2022-04-12
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * Creating a new type called Course, with fields name, code, Student and total_students.
 */
typedef struct _course 
{
  char name[100]; /**< Name of the course*/
  char code[10]; /**< Course code*/
  Student *students; /**< Array of students in the course*/
  int total_students; /**< NUmber of students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


